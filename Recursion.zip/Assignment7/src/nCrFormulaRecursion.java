//Bassit Ilahi
//6328318
//COP3337
//Assignment 7

import java.util.Scanner;

public class nCrFormulaRecursion {

	//method that is used to calculate factorial of a number. This method takes num as the input and returns 
	//a call to the method but with num-1 as the input until num=1. When num=1, the values are then substituted 
	//and multiplied with their respective num thus creating a recursion that calculates factorial
	public static int factorial(int num) {
		if(num==1) {
			return 1;
		}else {
			return factorial(num-1)*num;
		}
		
	}//end factorial method
	
	//method that accepts two input n and r. The method then lists the base/stopping conditions for the 
	//calculations. These default conditions are conditions that are mathematically defined such as 
	//numerator/denominator of a fraction being 0 or the numerator being less than the denominator
	public static int nCr(int n, int r) {
		if(n<r) {
			return -1;
		}else if(n==0 && r==0) {
			return 1;
		}else if(n==1 && r==1) {
			return 1;
		}else if(n==1 && r==0) {
			return 1;
		}else {
			return((factorial(n)) / ((factorial(r)) * (factorial(n-r)))); // this line returns the combinatorics 
																		  //formula using calls to the factorial 
																		  //method defined above. Thus returns results 
		}
		
	}//end nCr method
	
	//main method where we ask the user for input as for n and r then store these values
	//also prints out the total possible combinations calling to the above method of nCr which returns the results 
	//of the combinatorics which utilizes calls to the factorial method which is recursive
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter value for n: ");
		int n = keyboard.nextInt();
		System.out.println("Enter value for r: ");
		int r = keyboard.nextInt();
		
		System.out.println("There are " + nCr(n, r) + " possible combinations");

	}//end main

}//end class
