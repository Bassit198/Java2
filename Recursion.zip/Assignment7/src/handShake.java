//Bassit Ilahi
//6328318
//COP3337
//Assignment 7

import java.util.Scanner;

public class handShake {

	//method used to calculate the number of handshakes that will be present if everyone shakes hands once
	//method is static because it belongs to the handshake class and it returns an int value which will be the number of handshakes. 
	//this method also accepts an int value which will be the number of persons 
	public static int handShakeCalculator(int num) {
		//if there is one person then there can be no handshake
		if(num==1) {
			return 0;
		
		//if there is 2 persons then there can only be one handshake
		}else if(num==2) {
			return 1;
			
		//if more than 2 persons, there will be number of persons-1 because if that person shakes hand with everyone, there can be 
		//no repetition so we minus one from the total number of persons and keep adding the amount of handshakes 
		//then the handShakeCalculator method is called within itself making it recursive with the new total number of persons 
		//being num-1
		//this will continue until num==2 thus returning 1 and substituting all the values back up and add them together 
		//resulting in the number of handshakes if everyone shake hands once
		}else {
			return((num-1) + (handShakeCalculator(num-1)));
		}
	}
	
	
	//main method
	public static void main(String[] args) {
		
		//scanner object to receive user input followed by a prompt with instructions for the user 
		Scanner keyboard = new Scanner(System.in);
		System.out.println("How many people are in the room?");
		
		//stores the user's input
		int numberOfPeople = keyboard.nextInt();
		
		//a while loop that will only execute if the user enters a value less than one for the number of people prompting the 
		//user to enter a valid number
		while(numberOfPeople<1) {
			System.out.println("There must be atleast one person in the room. Please re-enter.");
			System.out.println("How many people are in the room?");
			numberOfPeople = keyboard.nextInt();
			
		}
		
		//prints out the number of handshakes within a message and also calling the handShakeCalculator method from above 
		//which returns the amount of handshakes 
		System.out.println("If everyone shakes hands once, there will be " + handShakeCalculator(numberOfPeople) + " handshakes");
		
		

	} //end main

} // end class 
