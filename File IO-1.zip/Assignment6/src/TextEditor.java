//Bassit Ilahi
//6328318
//COP3337
//Assignment 6


//import of all the needed packages
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

public class TextEditor {

	public static void main(String[] args){
		//scanner initialization to receive user's input then ask user to enter file to 
		//be edited then stores the file name in keyboard then closes the keyboard input stream
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter file name to be edited:");
		String fileName = keyboard.next();
		keyboard.close();
		
		//initialization of variable that will be used(initialized outside of try block
		//so can be used anywhere in main)
		FileInputStream input = null;
		Scanner source = null;
		PrintWriter target=null;
		
		
		//try block that creates the input stream and scanner object we will use to open
		//the file the user inputs 
		try {
			input=new FileInputStream(fileName);
			source=new Scanner(input);
			
		//catches the FileNotFouneException thrown by the above try block, handles the exception 
		//then exits the program
		}catch(FileNotFoundException e) {
			System.out.println("The file "+fileName+" cannot open.");
			System.exit(0);
		}
		
		//create new file object for the temp file
		File temp = new File("Temp1");
		
		
		//try block that creates the temp file as an output stream so we can write to it. Also lets 
		//the user know that the temp file was created
		try {
			target=new PrintWriter(new FileOutputStream(temp, true));
			System.out.println("Created Temp file!");

			//an empty string is created
			String paragraph="";
			
			//while loop that will run until the source file has no more elements. This loop will 
			//add all the lines from the source file to the empty string created above(this is done 
			//so that we can parse the string to whatever we need
			while(source.hasNext()) {
				paragraph+=source.nextLine();
			}
			
			//a string array which we use to store the parsed sentences(the sentences separated 
			//by period). We use the string of paragraph from above and split it at each period and 
			//store it in the string array, each sentence separated
			String[] sentenceList = paragraph.split("[.]");
			
			//copy the separated sentences to the temp file using an enhanced for loop that iterates 
			//through the entire string array created above and printing each sentences followed by a 
			//period
			for(String s: sentenceList) {
				target.println(s + ".");
			}
			//lets the user know that the text was formatted and copied to temp file
			System.out.println("Formatted text and copied to temp file!");
			
			//closes the input and output stream to prevent loss or corruption of data
			target.close();
			source.close();
			
		//catches the FileNotFouneException thrown by the above try block, handles the exception 
		//then exits the program	
		}catch(FileNotFoundException e) {
			System.out.println(e.getMessage());
			System.exit(0);
		}
		
		
		//try block that creates the source file as an output stream so we can write to it so as 
		//to replace the original text with the formatted text from the temp file and creates the 
		//temp file as the source of input so we can copy from the temp file
		//source file : output stream
		//temp file : input stream
		try {
			input=new FileInputStream(temp);
			source=new Scanner(input);
			target = new PrintWriter(new FileOutputStream(fileName));
			
		//catches the FileNotFouneException thrown by the above try block, handles the exception 
		//then exits the program
		}catch(FileNotFoundException e) {
			System.out.println(e.getMessage());
			System.exit(0);
		}
		
		//while loop that runs until there is no more character in the source file(in this case the 
		//temp file is the source)
		while(source.hasNext()) {
			//copies all the lines from the source file(temp) to the target file(source) 
			target.println(source.nextLine());	
		}
		//lets user know that the formatted text has been copied back to the source file 
		System.out.println("Formatteed text copied back to soure file!");
		
		//closes the input and output stream to prevent loss or corruption of data
		source.close();
		target.close();
		
		//method call to the deleteTempFile method
		deleteTempFile(temp);
		
		//lets user know that the process is done
		System.out.println("File formatting completed!");	
		
	}//end main
	
	//method used to delete file. Takes in an object of type file
	public static void deleteTempFile(File file) {
		
		//checks if the file coming in exists and if it does it will delete the file and let the 
		//user know the file was deleted and if it does not exist, a message lets the user know
		if(file.exists()) {
			file.delete();
			System.out.println("Temp file deleted!");
		}else {
			System.out.println("File does not exist.");
		}
	}//end method

}//end class
