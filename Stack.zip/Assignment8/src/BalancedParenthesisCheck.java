//Bassit Ilahi
//6328318
//COP3337
//Assignment 7

import java.util.Scanner;
import java.util.Stack;

public class BalancedParenthesisCheck {
//only pushing opening ones into stack 
//compare closed ones to pop from stack 
	
	//method that returns a boolean value and accepts a string as input. This method will be used to check if the parenthesis 
    //are balanced and if they are, it will return true
	public static boolean balancedCheck(String parenthesisExpression) {
		
		//an empty char variable is initialized to be used 
		char parenthesis;
		
		//a new stack that only holds character values because the parenthesis will be chars
		Stack<Character> stack = new Stack<>();
		
		//this for loop takes the parenthesis expression entered as a string and stores each value in the parenthesis char variable 
		for(int i=0; i<parenthesisExpression.length(); i++) {
			parenthesis = parenthesisExpression.charAt(i);
			
			//if statement that checks if the value of the parenthesis char is an opening parenthesis. If it is an opening 
			//parenthesis then it is pushed into the stack 
			if(parenthesis == '(' || parenthesis == '[' || parenthesis=='{') {
				stack.push(parenthesis); //push will add the parenthesis to the stack 
				
			//if the parenthesis is a closing parenthesis, we will check if the stack is empty and if it is then we will return false. 
			}else if(parenthesis == ')' || parenthesis == ']' || parenthesis =='}') {
				if(stack.empty()) {
					return false;
					
				//if the stack is not empty, we will pop the parenthesis from the stack and compare it to the parenthesis 
				//in the initial expression. If there is a closing parenthesis popped from the stack
				//then there must be an opening parenthesis in the expression at that index
				}else {
					char out = stack.pop();
					//this if statement will return false, if the parenthesis popped from the stack is the same as the parenthesis 
					//from the char variable
					//that is: if the parenthesis from the expression is an opening and the parenthesis popped from the stack is not 
					//a closing, then return false.
					if(parenthesis == ')' && out!='(' || parenthesis ==']' && out!='[' || parenthesis =='}' && out !='{') {
						return false;
					}
				}
			}
		}//end for loop 
		
		//stack.empty will return true if the user does not enter valid parenthesis since there will be no parenthesis in the stack
		return stack.empty();
		
	}//end blanacedCheck
	
	//main method 
	public static void main(String[] args) {
		//Scanner object created to receive input 
		Scanner keyboard = new Scanner (System.in);
		
		//instructions to the user is printed 
		System.out.println("Enter the parenthesis expression: ");
		
		//the scanner object is used to store the user's input in the expression string variable 
		String expression = keyboard.next();
		keyboard.close(); //close scanner to prevent data leak/corruption
		
		//using an if statement, a call to the balancedCheck method from above is made to compare the parenthesis. If the balanced 
		//check method return true, then a message will be printed, "Balanced" and if it returns false, then "Not Balanced" is printed
		if(balancedCheck(expression)) {
			System.out.println("Balanced");
		}else {
			System.out.println("Not Balanced");
		}

	}//end main

}//end class
