//Bassit Ilahi
//6328318
//COP3337

public class Vehicle {
	
	//instance variables
	private double tankSize = 0;
	private double efficiency =0;
	private double fuelInTank = 0.0;
	
	//mutator used to set the value of the tank size of the vehicle
	public void setTankSize(double tankSize) {
		this.tankSize=tankSize;
	}
	
	//mutator used to set the efficiency of the vehicle
	public void setEfficiency(double efficiency) {
		this.efficiency=efficiency;
	}
	
	//mutator used to set the fuel in the tank of the vehicle
	public void setFuelInTank(double fuelInTank) {
		this.fuelInTank=fuelInTank;
	}
	
	//accessor used to get and return the value of the tank size of the vehicle
	public double getTankSize() {
		return tankSize;
	}
	
	
	//accessor used to get and return the value of the efficiency of the vehicle
	public double getEfficiency() {
		return efficiency;
	}
	
	//accessor used to get and return the value of the fuel in tank of the vehicle
	public double getFuelInTank() {
		return fuelInTank;
	}
	
	
	//accessor used to calculate how much fuel can be filled depending on the fuel in tank and tank size
	public double availableTankCapacity() {
		return (tankSize-fuelInTank);
	}
	
	/*receives the amount of gallons of petrol to add and if the amount being added is greater than the tank 
	capacity, an error message is displayed
	otherwise, the gallons is added to the existing fuel in the tank and the value for the fuel in the tank is 
	updated then the gallons being added and the updated fuel in tank is displayed.
	Displays the distance that can be traveled by calling the driveTo method*/
	public void addPetrol(double gallons) {
        if(gallons>availableTankCapacity()) {
            System.out.println("Fuel Will Overflow.");
        }else {
            gallons+=fuelInTank;
            fuelInTank+=gallons;
            System.out.println("Adding " +gallons+ " gallons fuel to the tank.");
            System.out.println("Fuel In Tank = " +gallons+ " gallons");
            System.out.printf("You can travel %.2f miles with availabe fuel.", driveTo());  
            }
	}
	
	//returns the calculated distance that can be traveled with the available fuel and the efficiency of the vehicle
	public double driveTo() {
		return fuelInTank*efficiency;
	}
	
	
	
	

}
