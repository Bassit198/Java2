import java.util.Scanner;

public class VehicleDemo {

    public static void main(String[] args) {
        //creates new scanner instance to receive the input from the user
        Scanner sc = new Scanner(System.in);

        //creates an instance of the vehicle class
        Vehicle vehicle = new Vehicle();

        //asks user to input the size of the tank then sets the tank size of the vehicle instance
        //to that input
        System.out.println("Enter tank size of your car: ");
        vehicle.setTankSize(sc.nextDouble());

        //asks user to input the efficiency of the car of the vehicle instance then sets the
        //efficiency to that input
        System.out.println("Enter the efficiency of the car: ");
        vehicle.setEfficiency(sc.nextDouble());

        //outputs the fuel in the tank using the getter to return the value
        System.out.println("Fuel In Tank: " + vehicle.getFuelInTank());

        //outputs the total capacity of the tank using the getter to return the value of the tank size
        //received from the user
        System.out.println("Total Capacity of Tank = " + vehicle.getTankSize());

        //outputs the efficiency of the car using the getter to return the value received from the user
        System.out.println("Fuel Efficiency = " + vehicle.getEfficiency());

        //outputs the available capacity of the tank by calling the availableTankCapacity method
        System.out.println("Available Capacity of Tank = " + vehicle.availableTankCapacity());

        //asks the user to enter how much petrol they want to add to car
        System.out.println("How much gallons of petrol to add: ");
        
        /*calls the addPetrol method to add the user's input of petrol to the car and also displays
        the new updated fuel along with the distance that can be traveled with the new fuel using the 
        driveTo method*/
        vehicle.addPetrol(sc.nextDouble());
        
     
        
        
        
        }
    }



