//Bassit Ilahi
//6328318
//COP3337
//Assignment 5

import java.util.Scanner;

public class DateDemo {

	public static void main(String[] args) {
		
		//initialization of string array to store month names
		String[] monthName = {"January", "February", "March", "April", "May", "June", "July", "August", "September",
				  "Otober", "November", "December"};

		//initialization of all variables 
		int day=0;
		int dayCounter=0;
		int year=0;
		int month=0;
		
		//boolean value for the while loops 
		boolean done = true;
		
		//scanner to receive user's input
		Scanner scan = new Scanner(System.in);
		
		//print statement that instructs the user to input the date in a specific format
		System.out.println("Enter date to parse (MM/DD/YYYY format): ");
		
		
		//while loop to keep the program looping
		while(done) {
			//try block to handle the NumberFormatException being thrown by Integer.parseInt
			try {
				String date = scan.nextLine();
				String splitFormat[] = date.split("/");     //splits the user input at "/"
				month = Integer.parseInt(splitFormat[0]);   //takes the first part of the split and converts it from string to int
				day = Integer.parseInt(splitFormat[1]);     //takes the second part of the split and converts it from string to int
				year = Integer.parseInt(splitFormat[2]);    //takes the third part of the split and converts it from string to int
			}catch(NumberFormatException e) {
				continue; //restarts this while loop when the exception is catch
				
			}
			
		
			//while loop that checks validity of month and if the month is invalid, an exception of type 
			//MonthException is thrown and catch. Then there is a continue statement, which will restart 
			//the loop until a valid day is entered. If a valid day is entered, the program break out 
			//of this loop and prints the parsed date
			while(done) {
				try {
					if(month<1 || month>12) {
						throw new MonthException("Invalid Month. Reenter a valid month: "); //throwing the MonthException with a message
					}else {
						break;
					}
				}catch (MonthException e) {  //catching the MonthException being thrown
					System.out.println(e.getMessage());
					month = scan.nextInt();
					continue;
				}	
			}//end while loop for month check 
		
			
			//while loop that checks validity of year and if the year is invalid, an exception of type 
			//YearException is thrown and catch. Then there is a continue statement, which will restart 
			//the loop until a valid day is entered. If a valid day is entered, the program break out 
			//of this loop and prints the parsed date
			while(done) {
				if(year <1000 || year>3000) {
					try {
						throw new YearException("Invalid Year. Reenter a valid year: "); //throwing the YearException with a message
					}catch(YearException e) {  //catching the YearException being thrown
						System.out.println(e.getMessage());
						year = scan.nextInt();
						continue;
					}
				}else {
					break;
				}
			}//end while loop for year check 
			
			
			
			//days in the months assignments
				if(month==1) {
					dayCounter=31;
				
			//for February: checks for leap year being every 4 years (if leap year, days=29 else days=28)
				}else if(month==2) {
					if(year%400==0) {
						dayCounter=29;
					}else if(year%100==0) {
						dayCounter=28;
					}else if(year%4==0) {
						dayCounter=29;
					}else {
						dayCounter=28;
					}
				}else if(month==3) {
					dayCounter=31;
				}else if(month==4) {
					dayCounter=30;
				}else if(month==5) {
					dayCounter=31;
				}else if(month==6) {
					dayCounter=30;
				}else if(month==7) {
					dayCounter=31;
				}else if(month==8) {
					dayCounter=31;
				}else if(month==9) {
					dayCounter=30;
				}else if(month==10) {
					dayCounter=31;
				}else if(month==11) {
					dayCounter=30;
				}else if(month==12) {
					dayCounter=31;
				}
			
				//while loop that checks validity of day and if the day is invalid, an exception of type 
				//DayException is thrown and catch. Then there is a continue statement, which will restart 
				//the loop until a valid day is entered. If a valid day is entered, the program break out 
				//of this loop and prints the parsed date
				while(done) {
					if(day<1 || day>dayCounter) {
						try {
							throw new DayException("Invalid Day. Reenter a valid day: "); //throwing the DayException with a message
						}catch(DayException e) {  //catching the DayException being thrown
							System.out.println(e.getMessage());
							day = scan.nextInt();
							continue;
						}
					}else {
						break;
					}
				}//end while loop for day check 
		
				
				//print statement that prints the parsed information (Month name, day, year)
				System.out.println("Parsed date: " + monthName[month-1] + " " + day + ", " + year +"\n");	
				
				//print statement that instructs the user to input the date in a specific format before the loop runs again
				System.out.println("Enter date to parse (MM/DD/YYYY format): ");	
			
		}//end first while loop
		
		scan.close(); //closing the scanner object
		
		}//end main	
			
}//end class
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		
	


