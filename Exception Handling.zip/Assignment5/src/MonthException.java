//Bassit Ilahi
//6328318
//COP3337
//Assignment 5


//the class extends exception class because it is a custom exception class
public class MonthException extends Exception{
	
	//no argument constructor
	public MonthException() {
		super();
	}
	
	//argument constructor
	public MonthException(String message) {
		super(message);
	}

}
