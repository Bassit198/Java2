//Bassit Ilahi
//6328318
//COP3337
//Assignment 5


//the class extends exception class because it is a custom exception class
public class DayException extends Exception{

	//no argument constructor
	public DayException() {
		super();
	}
	
	//argument constructor
	public DayException(String message) {
		super(message);
	}
}
