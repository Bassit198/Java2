//Bassit Ilahi
//6328318
//COP3337
//Assignment 3

//SalariedEmployee class is a child class of Employee class. SalariedEmployee inherits all the properties of Employee class 
//so that we can reuse the code and not retype it
public class SalariedEmployee extends Employee{
	
	//instance variable that is not part of the Employee class but specific to the SalariedEmployee class
	private double salary;
	
	/*no argument constructor that calls super which basically uses the code that is in the parent class no argument 
	constructor. In this case, the no argument constructor is the employee class no argument constructor which also calls
	to the parent class of person. At this point, the SalariedEmployee no argument constructor has inherited properties of
	the employee class and the person class linked through the employee class.*/
	public SalariedEmployee() {
		super();
		this.salary=0;
	}
	
	/*an argument constructor that accepts 3 arguments. This constructor calls super with two arguments. This super is the 
	call to the Employee(name, hireDate). This employee constructor then calls super to the parent class, the person class. 
	which assigns the name then the hireDate then comes back to the salary. As we can see, this is like a linked chain 
	reaction that goes all back to the parent class since this class extend the employee class which extends the person 
	class*/
	public SalariedEmployee(String name, Date hireDate, double salary) {
		super(name, hireDate);
		this.salary=salary;
	}
	
	/*copy constructor which accepts a salariedEmployee as argument then calls super to the employee copy constructor which
	 then calls super to the person constructor which copies the name then back to the employee for hireDate then back to
	 salariedEmployee for salary. Thus copying*/
	public SalariedEmployee(SalariedEmployee objectSalariedEmployee) {
		super(objectSalariedEmployee);
		this.salary=objectSalariedEmployee.salary;
	}
	
	//Accessor method that returns the salary of the SalariedEmployee instance
	public double getSalary() {
		return salary;
	}

	//Mutator method which assigns/changes the salary of the SalariedEmployee instance
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	//toString method that calls super to the employee class' toString which prints out the employee information.
	//After which, prints out the salary of the SalariedEmployee instance using the getSalary() mutator
	public String toString() {
		return (super.toString() + " at a Salary $" + getSalary());
	}
	
	//calls super to the equals method of the employee class which checks if the employee name and hire date are equal
	//then checks if two salariedEmployee salary are equal. Will return true if all 3 are equal (name, hireDate, salary)
	public boolean equals(SalariedEmployee objectSalariedEmployee) {
		return(super.equals(objectSalariedEmployee) && getSalary()==objectSalariedEmployee.salary);
		
	}
}
