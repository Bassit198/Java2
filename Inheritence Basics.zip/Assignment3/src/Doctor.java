//Bassit Ilahi
//6328318
//COP3337
//Assignment 3

/*this translates to "Doctor class is the child class of the SalariedEmployee class"
the doctor class is now able to inherit the properties of the SalariedEmployee class which will enable us to reuse code without
having to rewrite*/
public class Doctor extends SalariedEmployee{
	
	//instance variables specific to the doctor class
	private String specialty;
	private double visitFee;
	
	//no argument constructor which calls super to the SalariedEmployee class' no argument constructor which then calls super to 
	//the employee class which then calls super to the parent class. This basically creates a default doctor using the information 
	//from the person class then adds no specialty and  0 visit fee.
	public Doctor() {
		super();
		this.specialty="No Specialty";
		this.visitFee=0;
	}
	
	//argument constructor which call super to the SalariedEmployee class' argument constructor which calls super to the employee 
	//class which then calls super to the parent class. This basically creates a default doctor using the information provided as 
	//arguments then assigns these values to the new Doctor instance being created along with specialty and visitFee.
	public Doctor(String name, Date hireDate, double salary, String specialty, double visitFee) {
		super(name, hireDate, salary);
		this.specialty=specialty;
		this.visitFee=visitFee;
	}
	
	
	//copy constructor calls super to the salariedEmployee copy constructor which follows the chain until the Person's class copy 
	//constructor. This basically takes a doctor as an argument and duplicates the properties because we assign the specialty and 
	//visit fee of the doctor received as argument to the new doctor instance. 
	public Doctor(Doctor objectDoctor) {
		super(objectDoctor);
		this.specialty=objectDoctor.specialty;
		this.visitFee=objectDoctor.visitFee;
	}

	//Accessor that returns the value of specialty of the doctor instance
	public String getSpecialty() {
		return specialty;
	}

	//Mutator method that assigns/change the specialty of the doctor instance
	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	//Accessor that returns the value of visitFee
	public double getVisitFee() {
		return visitFee;
	}

	//Mutator method that assigns/change the visitFee of the doctor instance
	public void setVisitFee(double visitFee) {
		this.visitFee = visitFee;
	}
	
	//toString method that calls super to the salariedEmployee class' toString which prints out the employee information.
	//After which, prints out the specialty and visitFee of the Doctor instance using the accessors and mutator
	public String toString() {
		return("The doctor " + super.toString()+ ".\n" + "The specialty is " + getSpecialty()+ " and visit fee is $" + 
				getVisitFee() + ".");
	}
	
	//calls super to the equals method of the employee class then checks if two doctor's specialty and visitFee are equal. 
	//Will return true if all are equal
	public boolean equals(Doctor objectDoctor) {
		return(super.equals(objectDoctor) && getSpecialty()==objectDoctor.getSpecialty() && 
				getVisitFee()==objectDoctor.getVisitFee());
	}

}
