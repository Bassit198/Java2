//Bassit Ilahi
//6328318
//COP3337
//Assignment 3

/*this translates to "Employee class is the child class of the Person class"
the employee class is now able to inherit the properties of the person class which will enable us to reuse code without
having to rewrite*/
public class Employee extends Person{

	//instance variable that is not in the base class but is specific to the employee class
	private Date hireDate;
	
	/*no argument constructor that calls super which is a call to the base class(Person). Because this call is made in the 
	no argument constructor then this calls the no argument base constructor and initializes all the data from the base.
	Because of this, there is no need to rewrite all the code from the base class no argument constructor. Then assigns a 
	default hireDate to the employee*/
	public Employee() {
		super();
		this.hireDate=new Date(1,1,1000);
	}
	
	/*an argument constructor that accepts name and hireDate. This constructor then calls super(name) from the base constructor 
	which is the constructor that accepts name in the base class. This is basically reusing the code written in the base class 
	name argument constructor than assigning the hireDate to this hireDate*/
	public Employee(String name, Date hireDate) {
		super(name);
		this.hireDate=hireDate;
	}
	
	/*a copy constructor that calls super() on the entered employee. This will then call the object constructor in the base class 
	 which will assign the properties of the employee to the person thus copying the properties*/
	public Employee(Employee objectEmployee) {
		super(objectEmployee);
		this.hireDate=objectEmployee.hireDate;
	}

	//Accessor method  that returns the hireDate of the employee instance
	public Date getHireDate() {
		return hireDate;
	}

	//Mutator method that assigns/change the hireDate of the employee instance
	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}
	
	//toString method that prints out the hire date of an employee 
	public String toString() {
		return(getName() + " was hired on " + getHireDate());
	}
	
	//equals method that checks if two employees are equal and  return true if they are
	public boolean equals(Employee objectEmployee) {
		return(getName().equals(objectEmployee.getName()) && getHireDate().equals(objectEmployee.getHireDate()));
	}
	
	
}
