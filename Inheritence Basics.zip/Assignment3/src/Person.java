//Bassit Ilahi
//6328318
//COP3337
//Assignment 3

public class Person {
	
	private String name;
	
	//a no argument constructor that prints a default value if it is called 
	public Person() {
		name="No person created";
	}
	
	//an argument constructor that creates a person instance and assigns the name to the name entered as the argument
	public Person (String name) {
		this.name=name;
	}
	
	/*a copy constructor that checks if the input person has been created. If the instance person is not created then 
	the program will exit and if the person is created, the name of the source person instance is assigned to the 
	new instance thus making a copy*/
	public Person(Person object) {
		if(object==null) {
			System.out.println("Error creating person");
		}else {
			this.name=object.name;
		}
	}
	
	//Accessor method that returns the name of the person created 
	public String getName() {
		return name;
	}
	
	//Mutator method that assigns/change the name to the person instance 
	public void setName(String name) {
		this.name=name;
	}
	
	//toString method that prints out the name of the person
	public String toString() {
		return ("The name is: " + getName());
				
	}
	
	//equals method that returns true if two person instances are equal
	public boolean equals(Person object) {
		return(this.name.equals(object.name));
	}

}
