//Bassit Ilahi
//6328318
//COP3337
//Assignment 3

/*this translates to "Patient class is the child class of the Person class"
the patient class is now able to inherit the properties of the Person class which will enable us to reuse code without
having to rewrite*/
public class Patient extends Person{
	
	//instance variables specific to the patient class. this instance variable is of type Doctor. 
	private Doctor primaryPhysician;
	
	//no argument constructor which calls super to the Person class. which will print the default value of the person. Then 
	//assigns a default doctor and specialty 
	public Patient() {
		super();
		this.primaryPhysician=new Doctor("No name", new Date(01,01,1000), 0, "No Specialty", 0);
	}
	
	//Argument constructor that calls super to the person class' argument constructor then assigns a primaryPhysician to that person.
	public Patient(String name, Doctor primaryPhysician) {
		super(name);
		this.primaryPhysician=primaryPhysician;
	}
	
	//copy constructor that has a person as an argument. This constructor will take all the properties of the inputed patient 
	//and assign them to a newly created instance thus copying it
	public Patient(Patient objectPatient) {
		super(objectPatient);
		this.primaryPhysician=objectPatient.primaryPhysician;
	}

	//Accessor that returns the value of primaryPhysician
	public Doctor getPrimaryPhysician() {
		return primaryPhysician;
	}

	//Mutator method that assigns/change the primaryPhysician of the patient instance
	public void setPrimaryPhysician(Doctor primaryPhysician) {
		this.primaryPhysician = primaryPhysician;
	}
	
	//toString method that prints out the name of the patient and their assigned doctor's name using accessors to return the names 
	public String toString() {
		return("The name is: " + getName() + ", Primary doctor is: " + getPrimaryPhysician().getName());
	}
	
	//equals method that checks if two patients are equal by checking if the patients information and primaryPhysician information are equal. 
	public boolean equals(Patient objectPatient) {
		return(super.equals(objectPatient) && getPrimaryPhysician()==objectPatient.getPrimaryPhysician());
	}

}
