//Bassit Ilahi
//6328318
//COP3337
//Assignment 3

/*this translates to "Billin class is the child class of the Patient class"
the billing class is now able to inherit the properties of the patient class which will enable us to reuse code without
having to rewrite*/
public class Billing extends Patient{
	
	//instance variable belonging to the billing class
	private double amountDue;

	//no argument constructor which calls super to the Patient class. which will print the default value of the patient. Then 
	//assigns a default amount due
	public Billing() {
		super();
		this.amountDue=0;
	}
	
	//Argument constructor that calls super to the patient class' argument constructor then assigns an amountDue to that patient 
	//in the billing instance.
	public Billing(Patient patient, double amountDue) {
		super(patient);
		this.amountDue=amountDue;
	}
	
	//copy constructor that copies a patient and amountDue to a newly created billing instance.
	public Billing(Billing objectBilling) {
		super(objectBilling);
		this.amountDue=objectBilling.amountDue;
	}

	//Accessor that returns the amountDue of the billing instance
	public double getAmountDue() {
		return amountDue;
	}

	//Mutator that assigns/change the amountDue of the billing instance
	public void setAmountDue(double amountDue) {
		this.amountDue = amountDue;
	}
	
	//toString that prints the billing information including patient, doctor and amount due
	public String toString() {
		return("Patient: "+ getName() + "\n" +
			   "Doctor: "+ getPrimaryPhysician().getName() + "\n" +
			   "Amount Due: $" + getAmountDue()+ "\n");
	}
}
