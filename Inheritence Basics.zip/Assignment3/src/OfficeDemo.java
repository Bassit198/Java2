//Bassit Ilahi
//6328318
//COP3337
//Assignment 3

public class OfficeDemo {

	public static void main(String[] args) {
		
		//lines 12-19 creates new doctor instances and assigns specific values received as arguments. Then calls the 
		//toString method of the doctor class thus printing the doctor's information.
		Doctor bob = new Doctor("Bob", new Date(12,31,1969), 34000, "Pediatrist", 10.5);
		System.out.println(bob);
		
		Doctor susan = new Doctor("Susan", new Date(12,31,1969), 450000, "Surgeon", 150);
		System.out.println(susan);
		
		Doctor lilly = new Doctor("Lilly", new Date(12,31,1969), 290000, "Kidney", 95.5);
		System.out.println(lilly);
		
		
		System.out.println();
		//prints a heading for organization
		System.out.println("*Patient's Information*");
		
		//lines 29-36 creates new patient instances and assigning specific values received as arguments. This patient 
		//instance accepts a string which is the name of the patient and then also accepts a Doctor's instance which will 
		//be assigned to that patient.After which calls toString of the patient class thus printing patient's name and doctor's name
		Patient fred = new Patient("Fred", bob);
		System.out.println(fred);
		
		Patient sally = new Patient("Sally", susan);
		System.out.println(sally);
		
		Patient john = new Patient("John", lilly);
		System.out.println(john);
		
		
		System.out.println();
		//prints a heading for organization
		System.out.println("*Billing's Information");
		
		
		//lines 45-52 creates new billing instances which assigns a patient with an amount due based on the doctor's visitFee. 
		Billing fredBill = new Billing(fred, fred.getPrimaryPhysician().getVisitFee());
		System.out.println(fredBill);

		Billing sallyBill = new Billing(sally, sally.getPrimaryPhysician().getVisitFee());
		System.out.println(sallyBill);
		
		Billing johnBill = new Billing(john, john.getPrimaryPhysician().getVisitFee());
		System.out.println(johnBill);
		
		
		System.out.println();
		//prints the total amount due based on the visitFee of each patient(using accessors to return the amountDue)
		System.out.println("The total income from billing records is: $" 
						   + (fredBill.getAmountDue()+sallyBill.getAmountDue()+johnBill.getAmountDue()));
		
	}

}
