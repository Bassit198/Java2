//Bassit Ilahi
//6328318
//COP3337
//ASSIGNMENT 4

//Manager class is a child class of employee class and inherits all of its properties
public class Manager extends Employee{

	//no argument constructor that calls super to the no argument constructor which is basically 
	//the no argument constructor of the employee class
	public Manager() {
		super();
	}
	
	//argument constructor that calls super to the argument constructor which is basically the argument 
	//constructor of the employee class
	public Manager(String employeeId, String name, String department, double salary, String designation) {
		super(employeeId, name, department, salary, designation);
	}
	
	//copy constructor that calls super to the copy constructor which is basically the copy constructor 
	//of the employee class
	public Manager(Manager other) {
		super(other);
	}
	
	//overridden addBonus method which is specifically for the manager class since the managers receive 
	//$300 bonus instead of $200
	public double addBonus() {
		return getSalary()+300;
	}
	
	//overridden display method which is specifically for the manager class in order to print out the manager's 
	//salary after adding the bonus
	public String display() {
		return(super.display() + "Salary after adding the bonus is: $" + addBonus() + "\n");
	}
}
