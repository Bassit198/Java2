//Bassit Ilahi
//6328318
//COP3337
//ASSIGNMENT 4

public class Employee {

	//instance variables
	private String employeeId;
	private String name;
	private String department; 
	private double salary;
	private String designation;
	
	//no argument constructor with default values for employee instance
	public Employee() {
		employeeId="0000";
		name="No Name";
		department="No Department";
		salary=0;
		designation="No Designation";
	}
	
	//argument constructor that creates an employee instance with the inputed arguments
	public Employee(String employeeId, String name, String department, double salary, String designation) {
		this.employeeId = employeeId;
		this.name = name;
		this.department = department;
		this.salary = salary;
		this.designation = designation;
	}
	
	//copy constructor that accepts an instance and assign the properties to this instance thus creating a copy
	public Employee(Employee other) {
		if(other==null) {
			System.out.println("Error creating employee");
		}else {
			this.employeeId = other.employeeId;
			this.name = other.name;
			this.department = other.department;
			this.salary = other.salary;
			this.designation = other.designation;
		}
	}
	
	//Accessor method that returns the
	public String getEmployeeId() {
		return employeeId;
	}
	
	//Mutator method that assigns/change employeeID to the received argument
	//prints an error message if the employeeID is not assigned
	public void setEmployeeId(String employeeId) {
		if(employeeId==null) {
			System.out.println("Employee object is not yet created");
		}else {
			this.employeeId = employeeId;
		}
	}
	
	//Accessor method that returns the name of employee
	public String getName() {
		return name;
	}
	
	//Mutator method that assigns/change the name to the received argument
	//prints an error message if the name is not assigned 
	public void setName(String name) {
		if(name==null) {
			System.out.println("Employee object is not yet created");
		}else {
			this.name = name;
		}
	}
	
	//Accessor method that returns the department of the employee
	public String getDepartment() {
		return department;
	}
	
	//Mutator method that assigns/change department to the received argument
	//prints an error message if the department is not assigned 
	public void setDepartment(String department) {
		if(department==null) {
			System.out.println("Employee object is not yet created");
		}else {
			this.department = department;
		}
	}
	
	//Accessor method that returns the salary of the employee
	public double getSalary() {
		return salary;
	}
	
	//Mutator method that assigns/change salary to the received argument
	//prints an error message if the salary is not assigned 
	public void setSalary(double salary) {
		if(salary<=0) {
			System.out.println("Salary is not yet created");
		}else {
			this.salary = salary;
		}
	}
	
	//Accessor method that returns the designation of the employee 
	public String getDesignation() {
		return designation;
	}
	
	//Mutator method that assigns/change designation to the received argument
	//prints an error message if the designation is not yet assigned/created
	public void setDesignation(String designation) {
		if(designation==null) {
			System.out.println("Employee object is not yet created");
		}else {
			this.designation = designation;
		}
	}
	
	//bonus method which returns the default bonus of employee by adding $200 to the salary
	public double addBonus() {
		return (this.salary+200);
	}
	
	//this method calculates and returns the deduction amount based on present and leave days 
	public double calculateDeduction(int leave, int present) {
		return (addBonus() * ((double)leave / (double)present));
	}
	
	//equals method that returns true if two employees designations are equal
	public boolean equals(Employee other) {
		return(getDesignation().equals(other.getDesignation())); 
	}
	
	//this method displays the employee information
	public String display() {
		return("Employee ID: " + getEmployeeId() + "\n" +
			   "Employee name: " + getName() + "\n" +
			   "Department name: " + getDepartment() + "\n" +
			   "Salary: $" + getSalary() + "\n" +
			   "Designation: " + getDesignation() + "\n");
	}
	

	
	
}
