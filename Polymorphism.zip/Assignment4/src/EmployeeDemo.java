//Bassit Ilahi
//6328318
//COP3337
//ASSIGNMENT 4

import java.util.Scanner;

public class EmployeeDemo {

	public static void main(String[] args) {
		
		//creating 3 employees each of which are of type Employee but they also have type manager or clerk
		//since manager and clerk are children of employee class
		Employee mark = new Manager("E001", "Mark", "HR", 15000, "Manager");
		Employee peter = new Manager("E012", "Peter", "R&D", 20000, "Manager");
		Employee samual = new Clerk("E056", "Samual", "Accounts", 10000, "Clerk");
		Employee robert = new Clerk("E097", "Robert", "Customer Support", 5000, "Clerk");
		
		//An employee array used to store the employee for easier reference
		Employee[] employeeArray = new Employee[4];
		employeeArray[0] = mark;
		employeeArray[1] = peter;
		employeeArray[2] = samual;
		employeeArray[3] = robert;
		
		//for loop that iterates through the employee array, calls the display method onto each employee and prints
		//since each employee also has a specific type(manager or clerk), the overridden respective display info will 
		//be called as opposed to the the employee class display being called because this method is was overridden 
		//for each class (Example: mark is of type manager so manager display will be called with his information)
		for(int i=0; i<employeeArray.length; i++) {
			System.out.println(employeeArray[i].display());
		}
		
		//check if two employees designation are equal and if they are equal, an identical designation statement is 
		// printed, otherwise, a different designation statement is printed		
		
		//designationCheck method call with two employee as arguments and this method will print whether or not two 
		//employees' designation is equal
		designationCheck(mark,samual);
		designationCheck(peter,mark);
		System.out.println();
		
		//scanner object that will be used to take user input
		Scanner sc = new Scanner(System.in);
		
		//int array that will store the user inputs for days present. This array has the size of the number of employees 
		//in the employeeArray so that way, each employee will have one input of number of days present
		int[] days = new int[employeeArray.length];
		
		//for loop that iterates through the days array and asks the user for input for each employeeId in each iteration,
		//stores this input into the days array
		//here, days[i] will point to employeeArray[i]
		for(int i=0; i<days.length; i++) {
			System.out.print("Enter the number of days Employee " + employeeArray[i].getEmployeeId() + " is Present out 20: ");
			days[i] = sc.nextInt();
		}
		
		//for loop that checks the days array for any input that is >20 or <0. If this is true, a message will tell the 
		//user which employeeId has the incorrect value and ask for another value then updates the value for that employeeId 
		//in the days array
		for(int i=0; i<days.length; i++) {
			if(days[i]>20 || days[i]<0) {
				System.out.println("Invalid days entered for Employee " + employeeArray[i].getEmployeeId()+ ".");
				System.out.print("Enter the number of days Employee " + employeeArray[i].getEmployeeId() + " is Present out 20: ");
				days[i] = sc.nextInt();
			}
		}
		
		//creates a table heading
		System.out.println();
		System.out.printf("%-20s%-20s%-20s%-20s\n", "Employee ID", "Present", "Absent", "Deductions");
		
		//for loop that iterates through the employeeArray
		for(int i=0; i<employeeArray.length; i++) {
			System.out.printf("%-20s%-20d%-20d$%-20.2f\n",
								employeeArray[i].getEmployeeId(),   //prints the value of the employeeId at position i in the employeeArray
								
								days[i], //prints the user input of days present from the days array at position i which corresponds to the 
										 //employee at position i
								
								20-days[i], //prints the days absent by subtracting the days present of position i in days array which 
											//corresponds to the employee at position i
								
								(employeeArray[i].calculateDeduction(20-days[i], 20))); //each employee at position i in the employeeArray 
																						//will call the calculateDeduction method which takes 
																						//in leave days (20-days[i]) and present days(days[i]) 
																						//to calculate the employee's deduction
		}
		
		
		
		//variable used to calculate total deduction
		double deduction=0;
		
		//for loop that iterates through the employeeArray and calculates the deduction by calling the calculateDeduction method on each employee 
		//with leave and present days as arguments to this method 
		//this calculated deduction is added to the deduction from line 87 then updates this value which will then be added to another deduction 
		//on the next iteration
		for(int i=0; i<employeeArray.length; i++) {
			double deduction1 = employeeArray[i].calculateDeduction(20-days[i], 20);
			deduction += deduction1;
		}
		
		//prints out the total deduction calculated from above
		System.out.println("\nTotal Deductions: $" + deduction);

	}///end main
	
	//designationCheck method uses the equals method of the employee class (that return true if two employees' designation are equal) to check if 
	//two employees are equal. The employees are passed as arguments and if the equals method is true (the two employees' designations are equal),
	//then a statement is printed that states the designations are identical otherwise, a statement that states they are different is printed
	public static void designationCheck(Employee employee1, Employee employee2) {
		if(employee1.equals(employee2)) {
			System.out.println(employee1.getName() + " and " + employee2.getName() + " have identical designations.");
		}else {
			System.out.println(employee1.getName() + " and " + employee2.getName() + " have different designations.");
		}
	}


}//end class
