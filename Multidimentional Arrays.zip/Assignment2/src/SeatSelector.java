//BASSIT ILAHI
//6328318
//COP3337
//ASSIGNMENT2

import java.util.Scanner;

public class SeatSelector {

	//taken variable is used to keep count of how many seats are taken 
	static int taken = 0; 
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		//creates 2D array with outer array being 7 units and inner being 4 units
		char[][] seats = new char [7][4]; 
		
		//a for loop which assigns ABCD to 7 vertical lines since outer loop value increases by 1 after each assignment so first iteration will be:
		//seats[1][0] = 'A', seats[1][1] = 'B', seats[1][2] = 'C', etc
		for(int i=0; i<7; i++) { 
			seats[i][0] = 'A';
			seats[i][1] = 'B';
			seats[i][2] = 'C';
			seats[i][3] = 'D';
		}
		
		
		String seatNumber = " ";
		String Q = " ";
		System.out.print("You will be selecting seats for this airplane.\n");
		
		//calls the printSeat method which is used to print the layout of the airplane seats
		printSeat(seats); 
		
		System.out.println();
		System.out.println("You will intput the seat selection using the row number and then the seat letter (ex - 3B)");
		System.out.println("Please enter the seat number or Q to quit\n");
		
		//prompts the user to enter a seat number and assigns the user input to the seatNumber variable
		seatNumber = sc.nextLine();
		
		//checks if the user enter Q and if the user enters Q, the program will terminate after giving a message
		if(seatNumber.equals("Q")) {
			System.out.println("Thank You");
			
			//instructs the program to terminate
			System.exit(0);
		}

		//while loop that will keep executing until taken seats > 28 and the seat number<0. This loop is where all of the main statements and displays are placed
		//since we want the necessary code to repeat about 28 times
		while(taken<28 && seatNumber.length()>0) {
			
			//converts the inputed character to an int value. This takes the character at index 0 and subtract the ASCII value of 1 thus resulting in int
			int row = seatNumber.charAt(0) - '1'; 
			
			//converts the inputed character to an int value. This takes the character at index 1 and subtract the ASCII value of A thus resulting in int
			int col = seatNumber.charAt(1) - 'A';
			
			//this if statement will only run if the user input an incorrect set of data (incorrect seat number or format). the conditions for this if statement is 
			//values out of the array size
			if(row<0 || row>7 || col<0 || col>4) {
				System.out.println("Incorrect format. Try again.");
				System.out.println("Please enter another seat number (ex - 3B) or Q to quit\n");
				seatNumber = sc.nextLine();
				if(seatNumber.equals("Q")) {
					System.out.println("Thank You");
					System.exit(0);
				}
				
				
			}else {
				/*this if statement will check if the value received from the user in the array is not X and if it is not X at that position, it will update that 
				position to an X. After that position is updated, 
				it will add 1 to the taken variable which will allow us to keep count of how many seats are taken because every time a position is updated to X, 
				the count increases by one
				After the count is taken, the newly updated available seats is displayed by calling the printSeat method then lets the user know how many seats are 
				available by calling the seatsAva method*/
				if(seats[row][col] != 'X') {   
					seats[row][col] = 'X';
					taken++;
					System.out.println(" ");
					printSeat(seats);
					seatsAva();	
				
				}else {
					System.out.println("Seat taken");} /*this statement will let the user know that a seat is taken if they enter a seat that is already taken because 
													   it is the else section of the above if statement, it will only execute if the condition above is false (will 
													   only execute if position entered has a value of X*/
			
			//this if statement checks if the seats taken is less than 28 (total seats) and if true, it will reprint the instructions for the user along with the exit 
			//program option code using system.exit
			if(taken < 28) {
				System.out.println("Please enter another seat number (ex - 3B) or Q to quit\n");
				seatNumber = sc.nextLine();
				if(seatNumber.equals("Q")) {
					System.out.println("Thank You");
					System.exit(0);
						
				}
					
			}
			}
				
		}
		
	}//end main
	
	//this method calculates the available seats remaining by subtracting the amount of taken seats from total seats
	private static void seatsAva() { 
		int availableSeats = (28-taken);
		System.out.println("There are "+availableSeats+" seats available.");
	}
	
	/*this method prints out the layout of the seats using a for loop. Since the size of the seat array is 7, the loop 
	will iterate through 7 vertical positions and print the value of the inner array which is ABCD followed by a space.
	This method accepts a 2D char array which is created in the main method.*/
	private static void printSeat(char[][] seats) {
		for(int i=0; i<seats.length; i++) {
			System.out.println((i+1) + " " + seats[i][0] + " " + seats[i][1] + " " + seats[i][2] + " " + seats[i][3]);
		}
		
	}
	
}//end class
